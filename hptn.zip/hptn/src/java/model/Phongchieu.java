/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;

/**
 *
 * @author ADMIN
 */
public class Phongchieu {

    private int id;
    private String ma;
    private String ten;
    private int soluongghe;
    private String dacdiem;
    private String trangthai;
    private int idRapchieu;
    private Ghe[] listGhe;

    public Phongchieu() {
        super();
    }

    public Phongchieu(int id, String ma, String ten, int soluongghe, String dacdiem, String trangthai, int idRapchieu, Ghe[] listGhe) {
        this.id = id;
        this.ma = ma;
        this.ten = ten;
        this.soluongghe = soluongghe;
        this.dacdiem = dacdiem;
        this.trangthai = trangthai;
        this.idRapchieu = idRapchieu;
        this.listGhe = listGhe;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public int getSoluongghe() {
        return soluongghe;
    }

    public void setSoluongghe(int soluongghe) {
        this.soluongghe = soluongghe;
    }

    public String getDacdiem() {
        return dacdiem;
    }

    public void setDacdiem(String dacdiem) {
        this.dacdiem = dacdiem;
    }

    public String getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(String trangthai) {
        this.trangthai = trangthai;
    }

    public int getIdRapchieu() {
        return idRapchieu;
    }

    public void setIdRapchieu(int idRapchieu) {
        this.idRapchieu = idRapchieu;
    }

    public Ghe[] getListGhe() {
        return listGhe;
    }

    public void setListGhe(Ghe[] listGhe) {
        this.listGhe = listGhe;
    }

    
}