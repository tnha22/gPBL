/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author ADMIN
 */
public class Lichchieu {

    private int id;
    private String ma;
    private String ngaythang;
    private int idPhim;
    private String trangthai;
    private int idKhunggio;
    private int idPhongchieu;
    private Quanli quanli;

    public Lichchieu() {
    }

    public Lichchieu(int id, String ma, String ngaythang, int idPhim, String trangthai, int idKhunggio, int idPhongchieu, Quanli quanli) {
        this.id = id;
        this.ma = ma;
        this.ngaythang = ngaythang;
        this.idPhim = idPhim;
        this.trangthai = trangthai;
        this.idKhunggio = idKhunggio;
        this.idPhongchieu = idPhongchieu;
        this.quanli = quanli;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMa() {
        return ma;
    }

    public void setMa(String ma) {
        this.ma = ma;
    }

    public String getNgaythang() {
        return ngaythang;
    }

    public void setNgaythang(String ngaythang) {
        this.ngaythang = ngaythang;
    }

    public int getIdPhim() {
        return idPhim;
    }

    public void setIdPhim(int idPhim) {
        this.idPhim = idPhim;
    }

    public String getTrangthai() {
        return trangthai;
    }

    public void setTrangthai(String trangthai) {
        this.trangthai = trangthai;
    }

    public int getIdKhunggio() {
        return idKhunggio;
    }

    public void setIdKhunggio(int idKhunggio) {
        this.idKhunggio = idKhunggio;
    }

    public int getIdPhongchieu() {
        return idPhongchieu;
    }

    public void setIdPhongchieu(int idPhongchieu) {
        this.idPhongchieu = idPhongchieu;
    }

    public Quanli getQuanli() {
        return quanli;
    }

    public void setQuanli(Quanli quanli) {
        this.quanli = quanli;
    }

   

}