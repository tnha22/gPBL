/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;
/**
 *
 * @author ADMIN
 */
public class Ghe {

    private int id;
    private String ten;
    private String loai;
    private int idPhongchieu;
    private int idGia;

    public Ghe() {
    }

    public Ghe(int id, String ten, String loai, int idPhongchieu, int idGia) {
        this.id = id;
        this.ten = ten;
        this.loai = loai;
        this.idPhongchieu = idPhongchieu;
        this.idGia = idGia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getLoai() {
        return loai;
    }

    public void setLoai(String loai) {
        this.loai = loai;
    }

    public int getIdPhongchieu() {
        return idPhongchieu;
    }

    public void setIdPhongchieu(int idPhongchieu) {
        this.idPhongchieu = idPhongchieu;
    }

    public int getIdGia() {
        return idGia;
    }

    public void setIdGia(int idGia) {
        this.idGia = idGia;
    }

    
       
}