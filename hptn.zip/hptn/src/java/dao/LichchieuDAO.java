/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dao;

import java.util.List;
import model.Lichchieu;

/**
 *
 * @author ADMIN
 */
public class LichchieuDAO extends DAO {

    public boolean luuLichchieu(Lichchieu lichchieu) {
        try {
            ps = connection.prepareStatement("INSERT INTO `tbllichchieu` "
                    + "(`Ma`, `Ngaythang`, `Trangthai`, `tblQuanliId`, `tblPhongchieuId`, `tblPhimId`, `tblKhunggioId`) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)");
            ps.setString(1, lichchieu.getMa());
            ps.setString(2, lichchieu.getNgaythang());
            ps.setString(3, lichchieu.getTrangthai());
            ps.setInt(4, 1);
            ps.setInt(5, lichchieu.getIdPhongchieu());
            ps.setInt(6, lichchieu.getIdPhim());
            ps.setInt(7, lichchieu.getIdKhunggio());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Lichchieu> getNgaychieutrong(int idPhongchieu) {
        return null;
    }

    public LichchieuDAO() {
        super();
    }

}
