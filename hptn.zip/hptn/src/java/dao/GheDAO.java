/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Ghe;
import model.Ve;

/**
 *
 * @author ADMIN
 */
public class GheDAO extends DAO {

    public GheDAO() {
        super();
    }

    public List<Ghe> getVitrighe(int idPhongchieu) {
        List<Ghe> listGhe = new ArrayList<>();
        try {
            ps = connection.prepareStatement("select * from `tblghe` where tblPhongchieuId = ?");
            ps.setInt(1, idPhongchieu);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                Ghe ghe = new Ghe();
                ghe.setIdPhongchieu(idPhongchieu);
                ghe.setId(resultSet.getInt("id"));
                ghe.setTen(resultSet.getString("Ten"));
                ghe.setLoai(resultSet.getString("Loai"));
                ghe.setIdGia(resultSet.getInt("tblGiaId"));
                listGhe.add(ghe);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listGhe;
    }

}
