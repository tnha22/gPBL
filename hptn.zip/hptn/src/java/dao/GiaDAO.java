/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Gia;

/**
 *
 * @author ADMIN
 */
public class GiaDAO extends DAO {

    public GiaDAO() {
        super();
    }

    public List<Gia> getGia() {
        List<Gia> listGia = new ArrayList<>();
        try {
            resultSet = statement.executeQuery("select * from `tblgia`");
            while (resultSet.next()) {
                Gia gia = new Gia();
                gia.setId(resultSet.getInt("Id"));
                gia.setMa(resultSet.getString("Ma"));
                gia.setGiave(resultSet.getFloat("Giave"));
                listGia.add(gia);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listGia;
    }

}
