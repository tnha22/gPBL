/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author ADMIN
 */
public class DAO {
    
    Connection connection;
    Statement statement;
    PreparedStatement ps;
    ResultSet resultSet;
    
    public DAO(){
        if(connection == null){
            String dbUrl = "jdbc:mysql://localhost:3306/hptn?autoReconnect=true&useSSL=false";
            String dbClass = "com.mysql.cj.jdbc.Driver";
            try {
                Class.forName(dbClass);
                connection = DriverManager.getConnection (dbUrl, "root","4102001xq");
                statement = connection.createStatement();
            }catch(ClassNotFoundException | SQLException e) {
                System.err.println(e);
            }
        }
    }
}