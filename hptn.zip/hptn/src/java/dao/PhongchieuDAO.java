/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Phongchieu;

/**
 *
 * @author ADMIN
 */
public class PhongchieuDAO extends DAO {

    public PhongchieuDAO() {
        super();
    }

    public List<Phongchieu> getPhongchieutrong() {
        List<Phongchieu> listPhongchieu = new ArrayList<>();
        try {
            resultSet = statement.executeQuery("select * from `tblphongchieu`");
            while (resultSet.next()) {
                Phongchieu phongChieu = new Phongchieu();
                phongChieu.setId(resultSet.getInt("Id"));
                phongChieu.setMa(resultSet.getString("Ma"));
                phongChieu.setTen(resultSet.getString("Ten"));
                phongChieu.setSoluongghe(resultSet.getInt("Soluongghe"));
                phongChieu.setDacdiem(resultSet.getString("Dacdiem"));
                phongChieu.setTrangthai(resultSet.getString("Trangthai"));
                listPhongchieu.add(phongChieu);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listPhongchieu;
    }
    
    public Phongchieu getPhongChieuById(int id) {
        Phongchieu phongchieu = new Phongchieu();
        phongchieu.setId(id);
        try {
            ps = connection.prepareStatement("select * from `tblphongchieu` where Id = ?");
            ps.setInt(1, id);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                phongchieu.setMa(resultSet.getString("Ma"));
                phongchieu.setTen(resultSet.getString("Ten"));
                phongchieu.setSoluongghe(resultSet.getInt("Soluongghe"));
                phongchieu.setDacdiem(resultSet.getString("Dacdiem"));
                phongchieu.setTrangthai(resultSet.getString("Trangthai"));
                phongchieu.setIdRapchieu(resultSet.getInt("tblRapchieuId"));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return phongchieu;
    }

}
