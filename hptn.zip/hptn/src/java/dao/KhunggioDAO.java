/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Khunggio;

/**
 *
 * @author ADMIN
 */
public class KhunggioDAO extends DAO {

    public KhunggioDAO() {
        super();
    }

    public List<Khunggio> getKhunggiotrong(int idLichchieu) {

        List<Khunggio> listKhunggio = new ArrayList<>();
        try {
            resultSet = statement.executeQuery("select * from `tblkhunggio`");
            while (resultSet.next()) {
                Khunggio khunggio = new Khunggio();
                khunggio.setId(resultSet.getInt("Id"));
                khunggio.setMa(String.valueOf(resultSet.getInt("Ma")));
                khunggio.setKhunggio(resultSet.getString("Khunggio"));
                khunggio.setTrangthai(resultSet.getString("Trangthai"));
                listKhunggio.add(khunggio);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listKhunggio;

    }

     
    public Khunggio getKhungGioById(int id) {
        Khunggio khunggio = new Khunggio();
        khunggio.setId(id);
        try {
            ps = connection.prepareStatement("select * from `tblkhunggio` where Id = ?");
            ps.setInt(1, id);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                khunggio.setMa(resultSet.getString("Ma"));
                khunggio.setKhunggio(resultSet.getString("Khunggio"));
                khunggio.setTrangthai(resultSet.getString("Trangthai"));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return khunggio;
    }

}
