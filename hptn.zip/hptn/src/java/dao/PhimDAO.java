/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package dao;

import java.util.ArrayList;
import java.util.List;
import model.Phim;

/**
 *
 * @author ADMIN
 */
public class PhimDAO extends DAO {

    public PhimDAO() {
        super();
    }
    
    public List<Phim> getTenphimhienco() {
        List<Phim> listPhim = new ArrayList<>();
        try {
            resultSet = statement.executeQuery("select * from tblphim");
            while (resultSet.next()) {
                Phim phim = new Phim();
                phim.setId(resultSet.getInt("Id"));
                phim.setMa(resultSet.getString("Ma"));
                phim.setTen(resultSet.getString("Ten"));
                phim.setLoai(resultSet.getString("Loai"));
                phim.setNamsanxuat(resultSet.getString("Namsanxuat"));
                phim.setMota(resultSet.getString("Mota"));
                listPhim.add(phim);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listPhim;
    }

    public Phim getPhimById(int id) {
        Phim phim = new Phim();
        phim.setId(id);
        try {
            ps = connection.prepareStatement("select * from `tblphim` where Id = ?");
            ps.setInt(1, id);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                phim.setLoai(resultSet.getString("Loai"));
                phim.setMa(resultSet.getString("Ma"));
                phim.setTen(resultSet.getString("Ten"));
                phim.setMota(resultSet.getString("Mota"));
                phim.setNamsanxuat(resultSet.getString("Namsanxuat"));
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return phim;
    }
}
